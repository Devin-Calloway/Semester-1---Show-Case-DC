package com.example.intent;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class MadLibs extends AppCompatActivity {
    private EditText editTextAdjective1;
    private EditText editTextPluralNoun;
    private EditText editTextPlace;
    private EditText editTextAnimal;
    private EditText editTextAdjective2;
    private EditText editTextVerbPast;
    private TextView textViewStory;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.madlibs);
        editTextAdjective1 = findViewById(R.id.editText_adjective1);
        editTextPluralNoun = findViewById(R.id.editText_plural_noun);
        editTextPlace = findViewById(R.id.editText_place);
        editTextAnimal = findViewById(R.id.editText_animal);
        editTextAdjective2 = findViewById(R.id.editText_adjective2);
        editTextVerbPast = findViewById(R.id.editText_verb_past);
        textViewStory = findViewById(R.id.textView_story);
        Button buttonCreateStory = findViewById(R.id.button_create_story);
        buttonCreateStory.setOnClickListener(v -> createStory());
        Button backButton = findViewById(R.id.button_back_to_main);
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(MadLibs.this, Main.class);
            startActivity(intent);});}
    private void createStory() {
        String adjective1 = editTextAdjective1.getText().toString();
        String pluralNoun = editTextPluralNoun.getText().toString();
        String place = editTextPlace.getText().toString();
        String animal = editTextAnimal.getText().toString();
        String adjective2 = editTextAdjective2.getText().toString();
        String verbPast = editTextVerbPast.getText().toString();
        if (adjective1.isEmpty() || pluralNoun.isEmpty() || place.isEmpty() || animal.isEmpty() || adjective2.isEmpty() || verbPast.isEmpty()) {
            textViewStory.setText("Please fill in all the fields to create your amazing story!");
            return;}
        String story = "Last summer, my friends and I went to " + place + " for a vacation. It was a very " + adjective1 + " trip. We saw many " + pluralNoun + ". One day, we ran into a " + animal + ". It was a very " + adjective2 + " encounter. We all " + verbPast + " home with amazing memories.";
        textViewStory.setText(story);}}
