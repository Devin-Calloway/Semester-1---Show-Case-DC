package com.example.intent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
public class ScifiName extends AppCompatActivity {
    EditText FirstNameTXT, LastNameTXT, CityTXT, SchoolTXT, PetTXT, CharacterTXT;
    Button generateBTN, backButton;
    TextView SciFiNameTXT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scifiname);
        FirstNameTXT = findViewById(R.id.FirstNameTXT);
        LastNameTXT = findViewById(R.id.LastNameTXT);
        CityTXT = findViewById(R.id.CityTXT);
        SchoolTXT = findViewById(R.id.SchoolTXT);
        PetTXT = findViewById(R.id.PetTXT);
        CharacterTXT = findViewById(R.id.CharacterTXT);
        generateBTN = findViewById(R.id.generateBTN);
        SciFiNameTXT = findViewById(R.id.SciFiNameTXT);
        backButton = findViewById(R.id.button_back_to_main);
        generateBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateSciFiName();}});
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScifiName.this, Main.class);
                startActivity(intent);}});}
    private void generateSciFiName() {
        String firstName = FirstNameTXT.getText().toString().trim();
        String lastName = LastNameTXT.getText().toString().trim();
        String city = CityTXT.getText().toString().trim();
        String school = SchoolTXT.getText().toString().trim();
        String petOrFood = PetTXT.getText().toString().trim();
        String siblingOrChar = CharacterTXT.getText().toString().trim();
        if (firstName.length() < 2 || lastName.length() < 3 || city.length() < 2 || school.length() < 3) {
            Toast.makeText(ScifiName.this, "check your inputs", Toast.LENGTH_LONG).show();
            SciFiNameTXT.setText("please make sure:\n- first name is 2 characters\n- last name is 3 characters\n- city is 2 characters\n- school is 3 characters");
            return;}
        String sciFiFirstName = firstName.substring(0, 2) + lastName.substring(0, 3);
        sciFiFirstName = sciFiFirstName.substring(0, 1).toUpperCase() + sciFiFirstName.substring(1).toLowerCase();
        String sciFiLastName = city.substring(0, 2) + school.substring(0, 3);
        sciFiLastName = sciFiLastName.substring(0, 1).toUpperCase() + sciFiLastName.substring(1).toLowerCase();
        String sciFiOrigin;
        if (petOrFood.length() >= 2 && siblingOrChar.length() >= 2) {
            sciFiOrigin = petOrFood.substring(0, 2) + siblingOrChar.substring(0, 2);
            sciFiOrigin = sciFiOrigin.substring(0, 1).toUpperCase() + sciFiOrigin.substring(1).toLowerCase();
        } else {
            sciFiOrigin = petOrFood + siblingOrChar;}
        String finalResult = sciFiFirstName + " " + sciFiLastName + " from the planet " + sciFiOrigin;
        SciFiNameTXT.setText(finalResult);}
}
