package com.example.intent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;
public class GuessANumber extends AppCompatActivity {
    private int secretNumber;
    private int strikes;
    private int score;
    private EditText editTextGuess;
    private TextView textViewFeedback;
    private TextView textViewStrikes;
    private TextView textViewScore;
    private Button buttonGuess;
    private Button buttonNewGame;
    private ImageView imageViewWin;
    private ImageView imageViewLose;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guessanumber);
        editTextGuess = findViewById(R.id.editText_guess);
        textViewFeedback = findViewById(R.id.textView_feedback);
        textViewStrikes = findViewById(R.id.textView_strikes);
        textViewScore = findViewById(R.id.textView_score);
        buttonGuess = findViewById(R.id.button_guess);
        buttonNewGame = findViewById(R.id.button_new_game);
        imageViewWin = findViewById(R.id.imageView_win);
        imageViewLose = findViewById(R.id.imageView_lose);
        Button backButton = findViewById(R.id.button_back_to_main);
        newGame();
        buttonGuess.setOnClickListener(v -> checkGuess());
        buttonNewGame.setOnClickListener(v -> newGame());
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(GuessANumber.this, Main.class);
            startActivity(intent);});}
    private void newGame() {
        secretNumber = new Random().nextInt(100) + 1;
        strikes = 10;
        score = 0;
        textViewFeedback.setText("");
        textViewStrikes.setText("Strikes left: " + strikes);
        textViewScore.setText("Score: " + score);
        editTextGuess.setText("");
        buttonGuess.setEnabled(true);
        editTextGuess.setEnabled(true);
        imageViewWin.setVisibility(View.GONE);
        imageViewLose.setVisibility(View.GONE);}
    private void checkGuess() {
        String guessText = editTextGuess.getText().toString();
        if (guessText.isEmpty()) {
            textViewFeedback.setText("Please enter a number.");
            return;}
        try {
            int guess = Integer.parseInt(guessText);
            strikes--;
            if (guess == secretNumber) {
                int roundScore = 50 + (strikes * 5);
                score += roundScore;
                textViewFeedback.setText("You got it! You earned " + roundScore + " points.");
                textViewScore.setText("Score: " + score);
                imageViewWin.setImageResource(R.drawable.youwin);
                imageViewWin.setVisibility(View.VISIBLE);
                buttonGuess.setEnabled(false);
                editTextGuess.setEnabled(false);
            } else if (strikes == 0) {
                textViewFeedback.setText("Game Over! The number was " + secretNumber);
                imageViewLose.setImageResource(R.drawable.gameover);
                imageViewLose.setVisibility(View.VISIBLE);
                buttonGuess.setEnabled(false);
                editTextGuess.setEnabled(false);
            } else if (guess < secretNumber) {
                textViewFeedback.setText("Too low!");
            } else {
                textViewFeedback.setText("Too high!");}
            textViewStrikes.setText("Strikes left: " + strikes);
        } catch (NumberFormatException e) {
            textViewFeedback.setText("Invalid number format.");}}}
